# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['agent']

package_data = \
{'': ['*']}

install_requires = \
['litellm>=1.48.2,<2.0.0',
 'openai==1.47.1',
 'pyautogen>=0.3.0,<0.4.0',
 'sentient-campaign-agents-api>=0.1.0,<0.2.0',
 'tenacity>=9.0.0,<10.0.0']

setup_kwargs = {
    'name': 'chagent',
    'version': '0.1.0',
    'description': 'A description of your project',
    'long_description': 'None',
    'author': 'thinker',
    'author_email': 'your@email.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.12,<4.0',
}


setup(**setup_kwargs)
