# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['agent']

package_data = \
{'': ['*']}

install_requires = \
['autogen==0.3.1', 'openai>=1.47.1,<2.0.0', 'tenacity>=9.0.0,<10.0.0']

setup_kwargs = {
    'name': 'simplewolf',
    'version': '0.0.1',
    'description': 'A description of your project',
    'long_description': 'None',
    'author': 'bond',
    'author_email': 'your@email.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.12,<4.0',
}


setup(**setup_kwargs)
